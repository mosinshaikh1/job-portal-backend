const Job = require('../models/Job');

exports.createJob = async (req, res) => {
  try {
    const { title, description, company, location } = req.body;
    const job = new Job({ title, description, company, location });
    await job.save();
    res.status(201).json({ message: 'Job posted successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getJobs = async (req, res) => {
  try {
    const jobs = await Job.find();
    res.json(jobs);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};
